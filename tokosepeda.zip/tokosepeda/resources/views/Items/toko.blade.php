@extends('layouts.app')
@section('title', 'sepeda')
@section('content')

@endsection